(function () {
  globalThis.DealerPilotPopupSettings = {
    buildDate: "2026-08-17",
    defaultBackendUrl: "https://app.1987dealerpilot.com",
    replitBackendUrl: "https://dealerpilot1987.replit.app",
  };
})();
